package com.example.baccaratfloating;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQ = 701;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 48, 32, 32);
        root.setBackgroundColor(0xFF111820);

        TextView title = new TextView(this);
        title.setText("BACCARAT FLOATING ANALYZER");
        title.setTextColor(0xFFD6A84F);
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 18);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("A small manual score tracker that floats over your casino website. It records Banker, Player and Tie results. Past outcomes do not reliably predict the next hand.");
        info.setTextColor(0xFFE4E8ED);
        info.setTextSize(16);
        info.setPadding(0, 8, 0, 24);
        root.addView(info);

        Button start = new Button(this);
        start.setText("Enable floating panel");
        root.addView(start);
        start.setOnClickListener(v -> enableOverlay());

        Button stop = new Button(this);
        stop.setText("Stop floating panel");
        root.addView(stop);
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));

        TextView foot = new TextView(this);
        foot.setText("No casino login access • No automatic betting • Manual entry only");
        foot.setTextColor(0xFF9BA8B5);
        foot.setTextSize(12);
        foot.setPadding(0, 24, 0, 0);
        root.addView(foot);
        setContentView(root);
    }

    private void enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                .setTitle("Allow display over other apps")
                .setMessage("Android needs this permission to show the analyzer above your browser.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Open settings", (d, w) -> {
                    Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                    startActivityForResult(i, OVERLAY_REQ);
                }).show();
            return;
        }
        startOverlayService();
    }

    private void startOverlayService() {
        Intent i = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        finish();
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == OVERLAY_REQ && Settings.canDrawOverlays(this)) startOverlayService();
    }
}
