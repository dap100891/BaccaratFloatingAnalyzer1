package com.example.baccaratfloating;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.*;
import android.widget.*;

import java.util.ArrayList;
import java.util.Locale;

public class OverlayService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;
    private final ArrayList<String> hands = new ArrayList<>();
    private TextView counts, history, analysis;
    private int banker, player, tie;
    private boolean expanded = true;

    @Override public void onCreate() {
        super.onCreate();
        createNotification();
        showPanel();
    }

    private void createNotification() {
        String channel = "baccarat_overlay";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channel, "Baccarat overlay", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        Notification n = new Notification.Builder(this, channel)
            .setContentTitle("Baccarat Analyzer is running")
            .setContentText("Tap Stop in the app to close the floating panel.")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(11, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else startForeground(11, n);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(8, 6, 8, 6);
        return t;
    }

    private GradientDrawableLike bg(int color) { return new GradientDrawableLike(color); }

    private void showPanel() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(12, 10, 12, 10);
        box.setBackground(bg(0xF0192029).drawable());
        box.setElevation(12);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("BACCARAT ANALYZER", 14, 0xFFFFD36A);
        title.setTypeface(null, 1);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button collapse = smallButton("—");
        top.addView(collapse);
        Button close = smallButton("×");
        top.addView(close);
        box.addView(top);

        counts = text("", 13, 0xFFE8EDF3);
        box.addView(counts);

        LinearLayout buttons = new LinearLayout(this);
        buttons.addView(resultButton("BANKER", 0xFFB94752, "B"), new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(resultButton("PLAYER", 0xFF2868A8, "P"), new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(resultButton("TIE", 0xFF94732A, "T"), new LinearLayout.LayoutParams(0, -2, 1));
        box.addView(buttons);

        history = text("Recent: —", 12, 0xFFCBD4DE);
        box.addView(history);
        analysis = text("Reference odds: Banker 45.86% • Player 44.62% • Tie 9.52%\nPast streaks do not predict the next hand.", 11, 0xFFFFD36A);
        box.addView(analysis);

        LinearLayout actions = new LinearLayout(this);
        Button undo = smallButton("UNDO");
        undo.setOnClickListener(v -> undo());
        Button reset = smallButton("RESET");
        reset.setOnClickListener(v -> reset());
        actions.addView(undo, new LinearLayout.LayoutParams(0, -2, 1));
        actions.addView(reset, new LinearLayout.LayoutParams(0, -2, 1));
        box.addView(actions);

        collapse.setOnClickListener(v -> {
            expanded = !expanded;
            counts.setVisibility(expanded ? View.VISIBLE : View.GONE);
            buttons.setVisibility(expanded ? View.VISIBLE : View.GONE);
            history.setVisibility(expanded ? View.VISIBLE : View.GONE);
            analysis.setVisibility(expanded ? View.VISIBLE : View.GONE);
        });
        close.setOnClickListener(v -> stopSelf());

        box.setOnTouchListener(new View.OnTouchListener() {
            int initialX, initialY; float touchX, touchY;
            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    initialX = params.x; initialY = params.y; touchX = e.getRawX(); touchY = e.getRawY(); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x = initialX + (int)(e.getRawX()-touchX);
                    params.y = initialY + (int)(e.getRawY()-touchY);
                    wm.updateViewLayout(panel, params); return true;
                }
                return false;
            }
        });

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
            (int)(getResources().getDisplayMetrics().widthPixels * 0.88f),
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        params.y = 100;
        panel = box;
        wm.addView(panel, params);
        refresh();
    }

    private Button smallButton(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(10); b.setMinWidth(0);
        b.setPadding(5, 0, 5, 0); return b;
    }

    private Button resultButton(String label, int color, String code) {
        Button b = new Button(this); b.setText(label); b.setTextSize(11);
        b.setTextColor(0xFFFFFFFF); b.setBackgroundColor(color);
        b.setPadding(2, 2, 2, 2);
        b.setOnClickListener(v -> add(code));
        return b;
    }

    private void add(String code) {
        hands.add(code);
        if (code.equals("B")) banker++; else if (code.equals("P")) player++; else tie++;
        refresh();
    }
    private void undo() {
        if (hands.isEmpty()) return;
        String last = hands.remove(hands.size()-1);
        if (last.equals("B")) banker--; else if (last.equals("P")) player--; else tie--;
        refresh();
    }
    private void reset() {
        hands.clear(); banker = player = tie = 0; refresh();
    }
    private void refresh() {
        if (counts == null) return;
        int total = hands.size();
        counts.setText(String.format(Locale.US, "Hands: %d     Banker: %d     Player: %d     Tie: %d", total, banker, player, tie));
        StringBuilder s = new StringBuilder("Recent: ");
        int start = Math.max(0, hands.size()-18);
        for (int i=start; i<hands.size(); i++) s.append(hands.get(i)).append("  ");
        if (hands.isEmpty()) s.append("—");
        history.setText(s.toString());
        if (total > 0) {
            analysis.setText(String.format(Locale.US,
                "Observed: B %.1f%% • P %.1f%% • T %.1f%%\nReference odds only; no reliable next-hand edge from streaks.",
                banker*100.0/total, player*100.0/total, tie*100.0/total));
        } else {
            analysis.setText("Reference odds: Banker 45.86% • Player 44.62% • Tie 9.52%\nPast streaks do not predict the next hand.");
        }
    }

    @Override public void onDestroy() {
        if (wm != null && panel != null) try { wm.removeView(panel); } catch (Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }

    // Small rounded background helper to keep this project dependency-free.
    private static class GradientDrawableLike {
        final android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        GradientDrawableLike(int color) { d.setColor(color); d.setCornerRadius(18f); d.setStroke(1, 0xFF596575); }
        android.graphics.drawable.Drawable drawable() { return d; }
    }
}
