BACCARAT FLOATING ANALYZER — SOURCE PROJECT

This is a native Android source project (not a prebuilt APK).
It provides a draggable floating overlay with manual Banker / Player / Tie entry,
counts, recent history, undo, reset, and baseline Baccarat reference odds.

IMPORTANT:
- It does not connect to your casino account or read the casino website.
- It does not place bets.
- Past Banker/Player/Tie patterns do not reliably predict the next hand.
- The overlay requires Android's "Display over other apps" permission.
- Android 14+ also displays an ongoing foreground-service notification while the panel runs.

BUILD:
1. Open this folder in an Android Gradle build environment.
2. Build the app's debug APK.
3. Install the APK on Android.
4. Open the app, tap Enable floating panel, grant "Display over other apps".
5. Open your casino website; the panel remains floating above it.
6. To stop it, reopen the app and tap Stop floating panel, or use Android app settings to force stop.

The project uses Android Gradle Plugin 8.6.1 and compileSdk 35.
The code has not been compiled or device-tested in this chat; a successful build may require
a compatible Gradle 8.7+ installation and Android SDK 35.
